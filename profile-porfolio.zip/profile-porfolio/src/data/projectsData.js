// import one from '../assets/jpg/landingPage.jpg'
import two from '../assets/svg/projects/two.svg'
import three from '../assets/svg/projects/three.svg'
import four from '../assets/svg/projects/four.svg'
import five from '../assets/svg/projects/five.svg'
import six from '../assets/svg/projects/six.svg'
import seven from '../assets/svg/projects/seven.svg'
import eight from '../assets/svg/projects/eight.svg'


export const projectsData = [
    
    {
        id: 2,
        projectName: 'Netflix Website',
        projectDesc: 'It is a web application watch Online Movies.',
        tags: ['HTML', 'CSS', 'JavaScript'],
        code: 'https://github.com/nikhiltekade/Netflix.com.git',
        demo: 'https://www.netflix.com/in/',
        image: 'https://assets.nflxext.com/ffe/siteui/vlv3/8f12b4f0-a894-4d5b-9c36-5ba391c63fbe/44355e66-dbf8-4dd8-ba6b-8e9e32ec6abd/IN-en-20230320-popsignuptwoweeks-perspective_alpha_website_medium.jpg'
    },
    {
        // id: 3,
        // projectName: 'Agoda Clone',
        // projectDesc: 'Agoda is one of the world fastest growing online travel booking platforms. From its beginnings as an e-commerce start-up based in Singapore in 2005.',
        // tags: ['RACT','REDUX','MONGODB','JSX','EXPRESS','MONGOOSE'],
        // code: 'https://github.com/shailendra7518/Agoda-clone',
        // demo: 'https://agoda-clone.vercel.app/',
        // image: 'https://i.ibb.co/5TJzyWQ/AGODA-CLONE.jpg'

        id: 3,
        projectName: 'Ecommerce Websites',
        projectDesc: 'Agoda is one of the world fastest growing online travel booking platforms. From its beginnings as an e-commerce start-up based in Singapore in 2005.',
        tags: ['RACT','REDUX','MONGODB','JSX','EXPRESS','MONGOOSE'],
        code: 'https://github.com/nikhiltekade/Ecom.git',
        demo: 'https://agoda-clone.vercel.app/',
        image: 'https://i.ibb.co/5TJzyWQ/AGODA-CLONE.jpg'
    },
    {
        id: 4,
        projectName: 'Weather App',
        projectDesc: 'Weather forecast systems and applications predict weather conditions based on multiple parameters.',
        tags: ['Openweather API', 'JavaScript', 'HTML', 'CSS'],
        code: 'https://github.com/webdeveshverma/Check-Weather-Appliction-',
        demo: 'https://webdeveshverma.github.io/Check-Weather-Appliction-/',
        // image: 'https://i.ibb.co/C9hZWVN/Weather-app.png'
    },
    {
        id: 5,
        projectName: 'NSE Website',
        projectDesc: 'Weather forecast systems and applications predict weather conditions based on multiple parameters.',
        tags: ['Openweather API', 'JavaScript', 'HTML', 'CSS'],
        code: 'https://github.com/webdeveshverma/Check-Weather-Appliction-',
        demo: 'https://webdeveshverma.github.io/Check-Weather-Appliction-/',
        // image: 'https://i.ibb.co/C9hZWVN/Weather-app.png'
    },
   
]


// Do not remove any fields.
// Leave it blank instead as shown below

/* 
{
    id: 1,
    projectName: 'Car Pooling System',
    projectDesc: '',
    tags: ['Flutter', 'React'],
    code: '',
    demo: '',
    image: ''
}, 
*/
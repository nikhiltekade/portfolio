export const educationData = [
    {
        id: 1,
        institution: 'ItPreneur Pune',
        course: 'Full Stack web-developer',
        startYear: 'feb 2022',
        endYear: 'Present'
    },
    {
        id: 2,
        institution: 'Pdm.Dr.v.b.kolte college of engineering,malkapur.',
        course: 'Deploma(Mechanical Enigineering)',
        startYear: 'Mechanical Enigineering',
        endYear: '2015'
    },
    {
        id: 3,
        institution: 'Pdm.Dr.v.b.kolte college of engineering,malkapur.',
        course: 'B.E.(Mechanical Enigineering)',
        startYear: '2015',
        endYear: '2018'
    },
]
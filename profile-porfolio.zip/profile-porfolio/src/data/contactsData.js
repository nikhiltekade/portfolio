export const contactsData = {
    email: 'nikhildtekade96@gmail.com',
    phone: '+91 9637193258',
    address: 'Akurdi,Pune.',

    sheetAPI: 'https://sheetdb.io/api/v1/tt5b8x0x5sbmo'
}

export const socialsData = {
    github: 'https://github.com/webdeveshverma',
    facebook: 'https://www.facebook.com/profile.php?id=100047654323640',
    linkedIn: 'https://www.linkedin.com/in/devesh-verma-6760761b8/',
    instagram: 'https://www.instagram.com/',
    codepen: 'https://codepen.io/',
    twitter: 'https://twitter.com/webdeveshverma',
    reddit: 'https://www.reddit.com/user/',
    blogger: 'https://www.blogger.com/',
    medium: 'https://medium.com/@webdeveshverma',
    stackOverflow: 'https://stackoverflow.com/users/',
    gitlab: 'https://gitlab.com/',
    youtube: 'https://youtube.com/'
}
export const blogData = [
    {
        id: 1,
         title: 'Websites Developement',
         description: 'Web development is the work involved in developing a website for the Internet (World Wide Web) or an intranet (a private network). Web development can range from developing a simple single static page of plain text to complex web applications, electronic businesses, and social network services.',
        // date: 'Feb 27, 2022',
        // image: 'https://i.ibb.co/WsSdXt7/blog1.png',
        // url: 'https://medium.com/@webdeveshverma/hello-reader-hope-you-are-keeping-safe-this-is-my-first-imagine-story-151333724c09'
    },
    {
         id: 2,
         title: 'Responsive Design',
         description: 'Responsive web design, or RWD, is a design approach that addresses the range of devices and device sizes, enabling automatic adaption to the screen, whether the content is viewed on a tablet, phone, television, or watch. Responsive web design is not a separate technology — it is an approach.',
        // date: 'Feb 27, 2022',
         image: 'https://i.ytimg.com/vi/B-ytMSuwbf8/maxresdefault.jpg',
        // url: 'hhttps://medium.com/@webdeveshverma/skills-vs-degrees-9f24c882f23b'
    },
    {
        id: 3,
        title: 'Database Development',
        description: 'FA database is a storing system that collects organized data, to make some works easier like searching, structure, and extend. In web development, most databases use the relational database management system (RDBMS) to organize data and programming in SQL',
        // date: 'March 19, 2022',
        image: 'https://cdn.dribbble.com/users/1592944/screenshots/14293996/media/6caf1b42f5e5a9aa31d9271318c3f5ee.png?compress=1&resize=400x300',
        url: 'hhttps://medium.com/@webdeveshverma/skills-vs-degrees-9f24c882f23b'
    },
   
   
]




// Do not remove any fields.
// Leave it blank instead as shown below.


/* 
{
    id: 1,
    title: 'Car Pooling System',
    description: '',
    date: 'Oct 1, 2020',
    image: '',
    url: 'https://preview.colorlib.com/theme/rezume/'
}, 
*/
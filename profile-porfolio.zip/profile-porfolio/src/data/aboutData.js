export const aboutData = {
    title: "Who I am",
    description1: "My name's Nikhil Tekade. I'm a Full-Stack Web Developer from Ghaziabad, Utter Pradesh.",
    description2: "I believe that the power of technology can make people's lives easier and that new frameworks and technology make developers more productive to the tech community. Learning HTML CSS and JavaScript from my Diploma journey, piqued my interest in coding. Since then my life has been about pursuing a career in coding and web development.",
    image: 1
}
